v1.2 업데이트
GitHub 저장소 루트에서 기존 HiddenBadge_Spine_Mobile_GitHub_Upload_Pack.zip 파일을 이 파일로 교체하세요.
그리고 ScenePack A5/A6/A7/A8 ZIP 4개도 저장소 루트에 올리세요.
기존 build-apk.yml은 수정할 필요 없습니다. Pack 교체 커밋이 자동으로 새 APK 빌드를 시작합니다.
