v1.2.1 수정본
- AndroidX 빌드 오류 수정(android.useAndroidX=true)
- 기존 GitHub Actions 파일 수정 불필요
- 이 ZIP을 저장소 루트의 HiddenBadge_Spine_Mobile_GitHub_Upload_Pack_v1.2.zip 자리에 교체 업로드하면 자동 빌드됩니다.
