이 ZIP을 GitHub 저장소 루트의 HiddenBadge_Spine_Mobile_GitHub_Upload_Pack_v1.2.zip 파일 자리에 교체 업로드하세요.
기존 build-apk.yml은 그대로 사용합니다.
빌드 후 앱 홈에서 [Yuri SAFE] 버튼을 누르고 장면을 선택하면 됩니다.
