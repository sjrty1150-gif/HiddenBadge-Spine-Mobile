HiddenBadge Spine Mobile - 폰에서 APK 만들기
===========================================

필요한 저장소:
https://github.com/sjrty1150-gif/HiddenBadge-Spine-Mobile

이 패키지에서 실제로 GitHub에 올릴 것은 2가지입니다.

1) UPLOAD_TO_REPO/HiddenBadgeSpineMobileProject.zip
2) COPY_THIS_TO_GITHUB_ACTIONS/build-apk.yml 의 내용

[1단계: 프로젝트 ZIP 올리기]
1. 폰 브라우저에서 GitHub 저장소를 엽니다.
2. Add file -> Upload files 선택
3. HiddenBadgeSpineMobileProject.zip 업로드
4. Commit changes

[2단계: Actions 파일 만들기]
1. 저장소에서 Add file -> Create new file 선택
2. 파일 이름 칸에 정확히 아래 경로 입력
   .github/workflows/build-apk.yml
3. 이 패키지의 COPY_THIS_TO_GITHUB_ACTIONS/build-apk.yml 파일 내용을 전부 복사해 붙여넣기
4. Commit changes

[3단계: APK 빌드]
- 위 workflow를 커밋하는 순간 자동 빌드가 시작될 수 있습니다.
- 자동으로 안 시작되면 저장소 상단 Actions 탭 -> Build Android APK -> Run workflow
- 초록색 체크가 뜰 때까지 기다립니다.

[4단계: APK 받기]
1. 완료된 Build Android APK 실행 내역을 누릅니다.
2. 페이지 아래 Artifacts에서 HiddenBadge-Spine-Mobile-APK 선택
3. ZIP을 받습니다.
4. 압축을 풀면 HiddenBadge-Spine-Mobile-debug.apk 가 있습니다.
5. APK를 눌러 설치합니다.
   Android가 출처 허용을 물으면 해당 브라우저/파일 앱의 '이 출처 허용'을 켭니다.

[앱 사용]
1. 앱 실행
2. 파일 열기
3. .skel + .atlas + 해당 PNG 전부 동시에 선택
4. 하단 메뉴에서 재생 / Bone / 파츠 / 저장 사용

주의
- 게임 원본 A5/A6/A7/A8 파일은 APK에 넣지 않았습니다.
- 사용자가 휴대폰 저장공간에서 직접 선택하는 구조입니다.
- 원본 파일 자체를 덮어쓰지 않고 런타임 patch를 저장합니다.
